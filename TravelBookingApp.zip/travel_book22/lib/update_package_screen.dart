import 'package:flutter/material.dart';



class UpdatePackageScreen extends StatelessWidget {

  @override

  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(title: Text('Update/Delete Packages')),

      body: ListView.builder(

        padding: const EdgeInsets.all(20),

        itemCount: 3, // mock data

        itemBuilder: (context, index) {

          return Card(

            child: ListTile(

              title: Text('Package ${index + 1}'),

              subtitle: Text('Price: \$100, Date: 2024-12-12'),

              trailing: Wrap(

                spacing: 10,

                children: [

                  IconButton(

                    icon: Icon(Icons.edit, color: Colors.green),

                    onPressed: () {

                      ScaffoldMessenger.of(context).showSnackBar(

                        SnackBar(content: Text('Edit Package ${index + 1}')),

                      );

                    },

                  ),

                  IconButton(

                    icon: Icon(Icons.delete, color: Colors.red),

                    onPressed: () {

                      ScaffoldMessenger.of(context).showSnackBar(

                        SnackBar(content: Text('Deleted Package ${index + 1}')),

                      );

                    },

                  ),

                ],

              ),

            ),

          );

        },

      ),

    );

  }

}