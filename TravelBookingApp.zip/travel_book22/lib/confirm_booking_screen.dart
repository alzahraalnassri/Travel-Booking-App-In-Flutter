import 'package:flutter/material.dart';

class ConfirmBookingScreen extends StatelessWidget {
  final String from;
  final String to;
  final String departureDate;
  final String returnDate;
  final int passengers;
  final String price;

  ConfirmBookingScreen({
    required this.from,
    required this.to,
    required this.departureDate,
    required this.returnDate,
    required this.passengers,
    required this.price,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Confirm Booking'),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Trip Details', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            SizedBox(height: 16),
            Text('From: $from'),
            Text('To: $to'),
            Text('Departure: $departureDate'),
            Text('Return: $returnDate'),
            Text('Passengers: $passengers'),
            Text('Total Price: $price'),
            SizedBox(height: 30),


            Center(
              child: ElevatedButton.icon(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Booking Confirmed!')),
                  );
                  Navigator.popUntil(context, (route) => route.isFirst);
                },
                icon: Icon(Icons.check),
                label: Text('Confirm Booking'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal,
                  padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                  textStyle: TextStyle(fontSize: 16),
                ),
              ),
            ),

            SizedBox(height: 20),


            Center(
              child: ElevatedButton.icon(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Booking Cancelled')),
                  );
                  Navigator.pop(context);
                },
                icon: Icon(Icons.cancel),
                label: Text('Cancel Booking'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.redAccent,
                  padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                  textStyle: TextStyle(fontSize: 16),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
