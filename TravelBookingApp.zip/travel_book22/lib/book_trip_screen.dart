import 'package:flutter/material.dart';
import 'flight_results_screen.dart';

class SelectFlightScreen extends StatefulWidget {
  @override
  _SelectFlightScreenState createState() => _SelectFlightScreenState();
}

class _SelectFlightScreenState extends State<SelectFlightScreen> {
  String? selectedFrom = 'JKT';
  String? selectedTo = 'SBY';
  DateTime? departureDate;
  DateTime? returnDate;
  int passengers = 1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.lightBlue[50],
      appBar: AppBar(
        title: Text('Select Flight'),
        backgroundColor: Colors.teal,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Departure & Destination Dropdown
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: selectedFrom,
                    decoration: InputDecoration(
                      labelText: 'From',
                      border: OutlineInputBorder(),
                      filled: true,
                      fillColor: Colors.white,
                    ),
                    items: ['JKT', 'DXB', 'MCT', 'CAI']
                        .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                        .toList(),
                    onChanged: (val) => setState(() => selectedFrom = val),
                  ),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: selectedTo,
                    decoration: InputDecoration(
                      labelText: 'To',
                      border: OutlineInputBorder(),
                      filled: true,
                      fillColor: Colors.white,
                    ),
                    items: ['SBY', 'LON', 'NYC', 'IST']
                        .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                        .toList(),
                    onChanged: (val) => setState(() => selectedTo = val),
                  ),
                ),
              ],
            ),

            SizedBox(height: 20),

            // Departure Date Picker
            GestureDetector(
              onTap: () async {
                DateTime? picked = await showDatePicker(
                  context: context,
                  initialDate: departureDate ?? DateTime.now(),
                  firstDate: DateTime.now(),
                  lastDate: DateTime(2026),
                );
                if (picked != null) {
                  setState(() => departureDate = picked);
                }
              },
              child: AbsorbPointer(
                child: TextFormField(
                  decoration: InputDecoration(
                    labelText: 'Departure Date',
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(),
                  ),
                  controller: TextEditingController(
                    text: departureDate == null
                        ? ''
                        : '${departureDate!.year}-${departureDate!.month}-${departureDate!.day}',
                  ),
                ),
              ),
            ),

            SizedBox(height: 20),

            // Return Date Picker
            GestureDetector(
              onTap: () async {
                DateTime? picked = await showDatePicker(
                  context: context,
                  initialDate: returnDate ?? DateTime.now().add(Duration(days: 3)),
                  firstDate: DateTime.now(),
                  lastDate: DateTime(2026),
                );
                if (picked != null) {
                  setState(() => returnDate = picked);
                }
              },
              child: AbsorbPointer(
                child: TextFormField(
                  decoration: InputDecoration(
                    labelText: 'Return Date',
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(),
                  ),
                  controller: TextEditingController(
                    text: returnDate == null
                        ? ''
                        : '${returnDate!.year}-${returnDate!.month}-${returnDate!.day}',
                  ),
                ),
              ),
            ),

            SizedBox(height: 20),

            // Passenger Count
            TextFormField(
              initialValue: passengers.toString(),
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Passengers',
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(),
              ),
              onChanged: (val) {
                final parsed = int.tryParse(val);
                if (parsed != null && parsed > 0) {
                  setState(() => passengers = parsed);
                }
              },
            ),

            SizedBox(height: 30),

            // Search Button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => FlightResultsScreen(
                        from: selectedFrom ?? '',
                        to: selectedTo ?? '',
                        departureDate: '${departureDate?.year}-${departureDate?.month}-${departureDate?.day}',
                        returnDate: '${returnDate?.year}-${returnDate?.month}-${returnDate?.day}',
                        passengers: passengers,
                      ),
                    ),
                  );
                },
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 14.0),
                  child: Text(
                    'Search',
                    style: TextStyle(fontSize: 18),
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
              ),

            ),
          ],
        ),
      ),
    );
  }
}
