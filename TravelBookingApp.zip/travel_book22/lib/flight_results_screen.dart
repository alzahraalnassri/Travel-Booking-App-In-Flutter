import 'package:flutter/material.dart';
import 'confirm_booking_screen.dart';

class FlightResultsScreen extends StatelessWidget {
  final String from;
  final String to;
  final String departureDate;
  final String returnDate;
  final int passengers;

  FlightResultsScreen({
    required this.from,
    required this.to,
    required this.departureDate,
    required this.returnDate,
    required this.passengers,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Available Flights'),
        backgroundColor: Colors.teal,
      ),
      body: ListView.builder(
        itemCount: 3, // mock results
        padding: const EdgeInsets.all(16),
        itemBuilder: (context, index) {
          return Card(
            margin: const EdgeInsets.symmetric(vertical: 10),
            child: ListTile(
              leading: Icon(Icons.flight, color: Colors.teal),
              title: Text('$from → $to'),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Departure: $departureDate'),
                  Text('Return: $returnDate'),
                  SizedBox(height: 8),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ConfirmBookingScreen(
                            from: from,
                            to: to,
                            departureDate: departureDate,
                            returnDate: returnDate,
                            passengers: passengers,
                            price: '\$${(index + 1) * 250}',
                          ),
                        ),
                      );
                    },
                    child: Text('Book Now'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.teal,
                    ),
                  ),
                ],
              ),
              trailing: Text('\$${(index + 1) * 250}'),
            ),
          );

        },
      ),
    );
  }
}
