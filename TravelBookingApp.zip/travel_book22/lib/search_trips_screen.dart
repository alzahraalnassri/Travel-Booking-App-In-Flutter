import 'package:flutter/material.dart';
import 'confirm_booking_screen.dart';

class SearchTripsScreen extends StatefulWidget {
  @override
  _SearchTripsScreenState createState() => _SearchTripsScreenState();
}

class _SearchTripsScreenState extends State<SearchTripsScreen> {
  final TextEditingController searchController = TextEditingController();

  final List<Map<String, String>> trips = [
    {
      'city': 'Sidney, AUS',
      'price': '\$899',
      'image': 'assets/images/sydney.jpg',
    },
    {
      'city': 'Bali, INA',
      'price': '\$799',
      'image': 'assets/images/bali.jpg',
    },
    {
      'city': 'London, UK',
      'price': '\$1,199',
      'image': 'assets/images/londonCity.jpeg',
    },
  ];

  List<Map<String, String>> filteredTrips = [];

  @override
  void initState() {
    super.initState();
    filteredTrips = trips;
    searchController.addListener(_filterTrips);
  }

  void _filterTrips() {
    String query = searchController.text.toLowerCase();
    setState(() {
      filteredTrips = trips.where((trip) {
        return trip['city']!.toLowerCase().contains(query);
      }).toList();
    });
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.lightBlue[50],
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: TextField(
                controller: searchController,
                decoration: InputDecoration(
                  hintText: 'Search destination...',
                  prefixIcon: Icon(Icons.search),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
              ),
            ),
            Expanded(
              child: filteredTrips.isNotEmpty
                  ? ListView.builder(
                itemCount: filteredTrips.length,
                itemBuilder: (context, index) {
                  final trip = filteredTrips[index];
                  return Container(
                    margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    height: 220,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      image: DecorationImage(
                        image: AssetImage(trip['image']!),
                        fit: BoxFit.cover,
                        colorFilter: ColorFilter.mode(
                          Colors.black.withOpacity(0.3),
                          BlendMode.darken,
                        ),
                      ),
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          bottom: 70,
                          left: 20,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                trip['city']!,
                                style: TextStyle(
                                  fontSize: 22,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                trip['price']!,
                                style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.yellow[300],
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Positioned(
                          bottom: 20,
                          right: 20,
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => ConfirmBookingScreen(
                                    from: 'Your City',
                                    to: trip['city']!,
                                    departureDate: '2025-06-01',
                                    returnDate: '2025-06-10',
                                    passengers: 1,
                                    price: trip['price']!,
                                  ),
                                ),
                              );
                            },
                            child: Text('Book Now'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.teal,
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              )
                  : Center(
                child: Text('No results found.',
                    style: TextStyle(color: Colors.grey)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
