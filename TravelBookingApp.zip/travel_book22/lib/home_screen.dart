import 'package:flutter/material.dart';
import 'search_trips_screen.dart';
import 'book_trip_screen.dart';
import 'profile_screen.dart';
import 'confirm_booking_screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  final List<Widget> _screens = [
    SearchTripsScreen(),
    SelectFlightScreen(),
    MyBookingsPlaceholder(),
    ProfileScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        backgroundColor: Colors.teal,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('EasyTrip'),
            Text(
              'Your journey begins here.',
              style: TextStyle(
                fontSize: 12,
                color: Colors.white70,
                fontStyle: FontStyle.italic,
              ),
            ),
          ],
        ),
      ),

      body: _screens[_selectedIndex],

      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        selectedItemColor: Colors.teal,
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.search), label: 'Search'),
          BottomNavigationBarItem(icon: Icon(Icons.flight_takeoff), label: 'Book'),
          BottomNavigationBarItem(icon: Icon(Icons.check_circle), label: 'My Bookings'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}


class MyBookingsPlaceholder extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: ElevatedButton.icon(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ConfirmBookingScreen(
                from: 'DXB',
                to: 'LON',
                departureDate: '2025-06-01',
                returnDate: '2025-06-08',
                passengers: 1,
                price: '\$699',
              ),
            ),
          );
        },
        icon: Icon(Icons.check),
        label: Text('Test Confirm Booking'),
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.teal,
          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          textStyle: TextStyle(fontSize: 16),
        ),
      ),
    );
  }
}
